/*4. Realizar la carga del lado de un cuadrado, mostrar por pantalla
el perímetro del mismo (El perímetro de un cuadrado se calcula
multiplicando el valor del lado por cuatro)
*/

/*
Prompt se utiliza para sacar un cuadro por pantalla que pregunte o 
haga algo
*/
let mensajeLado = "Lado";
let lado = prompt(mensajeLado);

document.write("El perímetro del cuadrado es " + (lado*4));