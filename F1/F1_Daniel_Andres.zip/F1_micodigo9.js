/*
        1. Realizar un programa que muestre su nombre y su edad en una
página HTML.
Emplear el comando write del objeto document para imprimir.
Tener en cuenta que si queremos que cada dato quede en una fila
distinta de la página debemos insertar la etiqueta HTML
(salto de linea en HTML)
        */
document.write("Daniel <br> 19");