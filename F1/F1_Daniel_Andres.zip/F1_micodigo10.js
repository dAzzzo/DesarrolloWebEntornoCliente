/*
2. Confeccionar un programa en JavaScript que defina e inicialice
una variable de tipo cadena de caracteres donde almacenemos el
nombre de un empleado y otra variable de tipo entera donde
almacenar el sueldo. Imprimir cada variable en una línea distinta
en pantalla.*/

//Var es más general y let especiifico pero es lo mismo
let nombre = "Daniel";
var sueldo = 2000;

console.log("El chico llamado " + nombre);
console.log("El suelo es " +  sueldo);