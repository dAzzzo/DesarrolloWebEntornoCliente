/*3. Confeccionar un programa que permita cargar el nombre de un
usuario y su mail por teclado. Mostrar posteriormente los datos
en la página HTML.
*/

let nombre = "Nombre";
let Nombre = prompt(nombre);

let email = "Email";
let Email = prompt(email);

document.write(Email + " es el email de " + Nombre);