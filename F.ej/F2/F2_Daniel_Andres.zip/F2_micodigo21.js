//13. Escriba un ejercicio de JavaScript para crear una variable con un nombre definido por el usuario.
let nombre = "Elige un nombre: ";
let Nombre = prompt(nombre);

document.write("La varible elegida es: " + Nombre); 
