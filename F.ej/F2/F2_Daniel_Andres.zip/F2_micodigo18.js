/*
10. Escriba un programa JavaScript para calcular la multiplicación y 
división de dos números (entrada del usuario).
*/

let numero1 = "Ingresa un número: ";
let num1 = prompt(numero1);

let numero2 = "Ingresa otro número: ";
let num2 = prompt(numero2);

document.write("El resultado si se multiplican es: " + (num1*num2) + "<br>");
document.write("La división de ambos números es: " + (num1/num2));