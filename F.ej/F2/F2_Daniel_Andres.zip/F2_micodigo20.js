//Busca la url de la propia página
var url = window.location.href;

//Lo pasamos por pantalla
document.write("La url es: " + url + "<br>");