/*Realiza un script que determine si la cadena de texto que se le pide al usuario es un palíndromo, es decir, si se lee de la misma forma desde la izquierda y desde la derecha. Ejemplo de palíndromo complejo: "La ruta nos aporto otro paso natural"
 */
